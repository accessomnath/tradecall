<?php
/**
 * Created by PhpStorm.
 * User: Somnath
 * Date: 10-Jan-17
 * Time: 5:53 PM
 * Template name: Webiners
 */
get_header()
?>

<section id="welcome-section-area">
    <div class="container">
        <div class="welcome-section-area-inner webiner">
            <div class="welcome-section-area-inner-heading text-center">
                <h2>Live Webinars</h2>
                <p><?php echo ot_get_option('webinar_content');?></p>
            </div>
            <div class="row webiner-inner">
                <div class="col-md-4 col-sm-6">
                    <a class="demo" href="https://www.youtube.com/watch?v=Gz2wBT9gZfo"><img src="images/youtube-img-1.jpg" class="img-responsive"></a>
                    <div class="webinnar-text">
                        <h2>Heading</h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsum labore eius praesentium dicta eveniet vel eligendi molestiae blanditiis aperiam quibusdam.</p>
                        <ul class="list-inline list-unstyled">
                            <li><span><i class="glyphicon glyphicon-calendar"></i> 01, 01 , 2017 </span></li>

                            <li>|</li>
                            <span>Posted by : Person name</span>

                            <li>|</li>
                            <li>
                                <!-- Use Font Awesome http://fortawesome.github.io/Font-Awesome/ -->
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <a class="demo" href="https://www.youtube.com/watch?v=Gz2wBT9gZfo"><img src="images/youtube-img-2.jpg" class="img-responsive"></a>
                    <div class="webinnar-text">
                        <h2>Heading</h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsum labore eius praesentium dicta eveniet vel eligendi molestiae blanditiis aperiam quibusdam.</p>
                        <ul class="list-inline list-unstyled">
                            <li><span><i class="glyphicon glyphicon-calendar"></i> 01, 01 , 2017 </span></li>

                            <li>|</li>
                            <span>Posted by : Person name</span>

                            <li>|</li>
                            <li>
                                <!-- Use Font Awesome http://fortawesome.github.io/Font-Awesome/ -->
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <a class="demo" href="https://www.youtube.com/watch?v=Gz2wBT9gZfo"><img src="images/youtube-img-3.jpg" class="img-responsive"></a>
                    <div class="webinnar-text">
                        <h2>Heading</h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsum labore eius praesentium dicta eveniet vel eligendi molestiae blanditiis aperiam quibusdam.</p>
                        <ul class="list-inline list-unstyled">
                            <li><span><i class="glyphicon glyphicon-calendar"></i> 01, 01 , 2017 </span></li>

                            <li>|</li>
                            <span>Posted by : Person name</span>

                            <li>|</li>
                            <li>
                                <!-- Use Font Awesome http://fortawesome.github.io/Font-Awesome/ -->
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="col-md-4 col-sm-6">
                    <a class="demo" href="https://www.youtube.com/watch?v=Gz2wBT9gZfo"><img src="images/youtube-img-4.jpg" class="img-responsive"></a>
                    <div class="webinnar-text">
                        <h2>Heading</h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsum labore eius praesentium dicta eveniet vel eligendi molestiae blanditiis aperiam quibusdam.</p>
                        <ul class="list-inline list-unstyled">
                            <li><span><i class="glyphicon glyphicon-calendar"></i> 01, 01 , 2017 </span></li>

                            <li>|</li>
                            <span>Posted by : Person name</span>

                            <li>|</li>
                            <li>
                                <!-- Use Font Awesome http://fortawesome.github.io/Font-Awesome/ -->
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <a class="demo" href="https://www.youtube.com/watch?v=Gz2wBT9gZfo"><img src="images/youtube-img-5.jpg" class="img-responsive"></a>
                    <div class="webinnar-text">
                        <h2>Heading</h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsum labore eius praesentium dicta eveniet vel eligendi molestiae blanditiis aperiam quibusdam.</p>
                        <ul class="list-inline list-unstyled">
                            <li><span><i class="glyphicon glyphicon-calendar"></i> 01, 01 , 2017 </span></li>

                            <li>|</li>
                            <span>Posted by : Person name</span>

                            <li>|</li>
                            <li>
                                <!-- Use Font Awesome http://fortawesome.github.io/Font-Awesome/ -->
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <a class="demo" href="https://www.youtube.com/watch?v=Gz2wBT9gZfo"><img src="<?php bloginfo('template_url'); ?>/images/youtube-img-6.jpg" class="img-responsive"></a>
                    <div class="webinnar-text">
                        <h2>Heading</h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsum labore eius praesentium dicta eveniet vel eligendi molestiae blanditiis aperiam quibusdam.</p>
                        <ul class="list-inline list-unstyled">
                            <li><span><i class="glyphicon glyphicon-calendar"></i> 01, 01 , 2017 </span></li>

                            <li>|</li>
                            <span>Posted by : Person name</span>

                            <li>|</li>
                            <li>
                                <!-- Use Font Awesome http://fortawesome.github.io/Font-Awesome/ -->
                            </li>
                        </ul>
                    </div>
                </div>


            </div>


        </div>
    </div>

</section>


<?php get_footer();?>
