<?php
/**
 * Created by PhpStorm.
 * User: Somnath
 * Date: 10-Jan-17
 * Time: 5:48 PM
 * Template name: home
 */
get_header();
?>

    <!--  Menu area ends  -->

    <!--  Slider area Starts  -->

    <section class="jk-slider">
        <div id="carousel-example" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carousel-example" data-slide-to="0" class="active"></li>
                <li data-target="#carousel-example" data-slide-to="1"></li>
                <li data-target="#carousel-example" data-slide-to="2"></li>
            </ol>

            <div class="carousel-inner">
                <?php
                /**
                 * Custom Slug Name slider
                 */
                global $post;
                $args = array(
                    'posts_per_page' => 3,
                    'orderby' => 'date',
                    'order' => 'DESC',
                    'post_type' => 'slider',
                    'post_status' => 'publish'
                );
                $i = 0;
                $class = "";
                $the_query = new WP_Query($args);
                while ($the_query->have_posts()) :
                    $the_query->the_post();
                    $url = wp_get_attachment_url(get_post_thumbnail_id($post->ID));
                    $i++;
                    if ($i == 1) {
                        $class = 'active';
                    } else {
                        $class = '';
                    }
                    ?>
                    <div class="item <?php echo $class ?>">
                        <a href="#"><img src="<?php echo $url; ?>"/></a>

                    </div>
                <?php endwhile; ?>
            </div>

            <a class="left carousel-control" href="#carousel-example" data-slide="prev">
                <span class="glyphicon glyphicon-chevron-left"></span>
            </a>
            <a class="right carousel-control" href="#carousel-example" data-slide="next">
                <span class="glyphicon glyphicon-chevron-right"></span>
            </a>
        </div>

        <div class="scroll-down-bottom wow bounce animated infinite" data-wow-duration="3s" data-wow-delay="2s">
            <a class="down" href="#welcome-section-area"><i class="fa fa-angle-double-down"></i></a>
        </div>


    </section>


    <!--  Slider area Ends  -->


    <!--  welcome-section area starts  -->

    <section id="welcome-section-area">
        <div class="container">
            <div class="welcome-section-area-inner">
                <div class="welcome-section-area-inner-heading text-center">
                    <h2>welcome-section</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ipsum labore eius praesentium dicta
                        eveniet
                        vel eligendi molestiae blanditiis aperiam quibusdam.</p>
                </div>

                <div class="welcome-section-area-inner-details">
                    <div class="col-md-3 col-sm-3">
                        <div class="welcome-section-area-inner-details-content">
                            <img src="<?php bloginfo('template_url'); ?>/images/welcome-icon-5.png"
                                 class="img-responsive"
                                 alt="">
                            <h2>Live Webinars</h2>
                            <p><?php echo ot_get_option('webinar_content');?></p>
                            <a href="#">read more</a>
                        </div>
                    </div>

                    <div class="col-md-3 col-sm-3">
                        <div class="welcome-section-area-inner-details-content">
                            <img src="<?php bloginfo('template_url'); ?>/images/welcome-icon-3.png"
                                 class="img-responsive"
                                 alt="">
                            <h2>Traders Education</h2>
                            <p><?php echo ot_get_option('trader_content');?></p>
                            <a href="#">read more</a>
                        </div>
                    </div>

                    <div class="col-md-3 col-sm-3">
                        <div class="welcome-section-area-inner-details-content">
                            <img src="<?php bloginfo('template_url'); ?>/images/welcome-icon-4.png"
                                 class="img-responsive"
                                 alt="">
                            <h2>Algorithmic Trading</h2>
                            <p><?php echo ot_get_option('algorithmic_trading_conent');?></p>
                            <a href="#">read more</a>
                        </div>
                    </div>

                    <div class="col-md-3 col-sm-3">
                        <div class="welcome-section-area-inner-details-content">
                            <img src="<?php bloginfo('template_url'); ?>/images/welcome-icon-2.png"
                                 class="img-responsive"
                                 alt="">
                            <h2>Trade Alerts</h2>
                            <p><?php echo ot_get_option('trade_alerts_content');?></p>
                            <a href="#">read more</a>
                        </div>
                    </div>

                </div>

            </div>
        </div>

    </section>


    <!--  welcome-section area ends  -->


    <!--  introduction-section area starts  -->

    <section id="introduction-area">
        <div class="container">
            <div class="introduction-area-inner">
                <div class="introduction-area-inner-heading text-center">
                    <h2>introduction</h2>
                </div>

                <div class="introduction-area-inner-details">
                    <div class="col-sm-6">
                        <div class="introduction-area-inner-details-content-left">
                            <h3>About Trade Call</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Omnis, eveniet unde! Enim odit,
                                esse maxime officia adipisci, autem ut culpa voluptate sit recusandae laudantium
                                deleniti
                                nostrum eligendi nam delectus suscipit totam omnis facilis temporibus ipsum sed,
                                repudiandae
                                deserunt qui ipsam. Culpa, ipsam quibusdam iusto itaque.</p>
                            <a href="#">read more</a>
                        </div>

                    </div>
                    <div class="col-sm-6">

                        <div class="introduction-area-inner-details-content-right">
                            <img src="<?php bloginfo('template_url'); ?>/images/introduction-area-image.jpg"
                                 class="img-responsive" alt="">
                        </div>
                    </div>

                </div>

            </div>


        </div>


    </section>


    <!--  introduction-section area ends  -->

    <!-- testimonial  area starts -->

    <section id="testimonial-area">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="testimonial-area-heading text-center">
                        <h2>testimonial area</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-8 col-md-offset-2">
                    <div class="testimonial-slider">
                        <div class="item">
                            <blockquote><q>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque
                                    ultrices,
                                    odio quis dignissim imperdiet, est tortor blandit neque, nec dictum sapien nibh ac
                                    neque.</q></blockquote>
                            <div class="testimonial-writer">
                                <div class="testimonial-writer-img"><img
                                        src="<?php bloginfo('template_url'); ?>/images/testimonial-image.png"
                                        class="img-responsive img-circle"
                                        alt="image-description"></div>
                                <div class="writer-description">
                                    <p>person name</p>
                                    <p>person designation</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <blockquote><q>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque
                                    ultrices,
                                    odio quis dignissim imperdiet, est tortor blandit neque, nec dictum sapien nibh ac
                                    neque.</q></blockquote>
                            <div class="testimonial-writer">
                                <div class="testimonial-writer-img"><img
                                        src="<?php bloginfo('template_url'); ?>/images/testimonial-image.png"
                                        class="img-responsive img-circle"
                                        alt="image-description"></div>
                                <div class="writer-description">
                                    <p>person name</p>
                                    <p>person designation</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <blockquote><q>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque
                                    ultrices,
                                    odio quis dignissim imperdiet, est tortor blandit neque, nec dictum sapien nibh ac
                                    neque.</q></blockquote>
                            <div class="testimonial-writer">
                                <div class="testimonial-writer-img"><img
                                        src="<?php bloginfo('template_url'); ?>/images/testimonial-image.png"
                                        class="img-responsive img-circle"
                                        alt="image-description"></div>
                                <div class="writer-description">
                                    <p>person name</p>
                                    <p>person designation</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <blockquote><q>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque
                                    ultrices,
                                    odio quis dignissim imperdiet, est tortor blandit neque, nec dictum sapien nibh ac
                                    neque.</q></blockquote>
                            <div class="testimonial-writer">
                                <div class="testimonial-writer-img"><img
                                        src="<?php bloginfo('template_url'); ?>/images/testimonial-image.png"
                                        class="img-responsive img-circle"
                                        alt="image-description"></div>
                                <div class="writer-description">
                                    <p>person name</p>
                                    <p>person designation</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <blockquote><q>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque
                                    ultrices,
                                    odio quis dignissim imperdiet, est tortor blandit neque, nec dictum sapien nibh ac
                                    neque.</q></blockquote>
                            <div class="testimonial-writer">
                                <div class="testimonial-writer-img"><img
                                        src="<?php bloginfo('template_url'); ?>/images/testimonial-image.png"
                                        class="img-responsive img-circle"
                                        alt="image-description"></div>
                                <div class="writer-description">
                                    <p>person name</p>
                                    <p>person designation</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- testimonial area ends -->

    <!----serach-panel----->
    <section id="search-palen-area">
        <div class="container">
            <div class="row">
                <div class="col-sm-8">
                    <div class="search-text">
                        <h5>Register Now!</h5>
                        <h3><?php echo ot_get_option('register');?></h3>
                    </div>
                </div>
                <div class="col-sm-4">
                    <a class="castom-button" href="<?php echo site_url(); ?>/register">Register for free</i></a>
                </div>
            </div>
        </div>
    </section>


    <!----serach-panel----->


<?php get_footer(); ?>