<?php
/**
 * Created by PhpStorm.
 * User: Somnath
 * Date: 10-Jan-17
 * Time: 5:53 PM
 * Template name: Trade Alerts
 */
get_header()
?>

<section id="news-section">
    <div class="container">
        <div class="news-section-inner">
            <div class="news-section-inner-heading text-center">
                <h2>News</h2>
                <p><?php echo ot_get_option('trade_alerts_content');?></p>

            </div>



            <div class="news-main-content">
                <div class="well">
                    <div class="media">
                        <a class="pull-left" href="#">
                            <img class="media-object img-responsive" src="images/news-image2.jpg"/>
                        </a>
                        <div class="media-body">
                            <h4 class="media-heading">Heading</h4>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis pharetra varius quam sit amet vulputate.
                                Quisque mauris augue, molestie tincidunt condimentum vitae, gravida a libero. Aenean sit amet felis
                                dolor, in sagittis nisi. Sed ac orci quis tortor imperdiet venenatis. Duis elementum auctor accumsan.
                                Aliquam in felis sit amet augue.</p>
                            <ul class="list-inline list-unstyled">
                                <li><span><i class="glyphicon glyphicon-calendar"></i> dd, mm , yy </span></li>

                                <li>|</li>
                                <span>Posted by......Name</span>

                                <li>|</li>
                                <li>
                                    <!-- Use Font Awesome http://fortawesome.github.io/Font-Awesome/ -->
                                    <span><i class="fa fa-facebook-square"></i></span>
                                    <span><i class="fa fa-twitter-square"></i></span>
                                    <span><i class="fa fa-google-plus-square"></i></span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="well">
                    <div class="media">
                        <a class="pull-left" href="#">
                            <img class="media-object img-responsive" src="images/news-image.jpg" alt=""/>
                        </a>
                        <div class="media-body">
                            <h4 class="media-heading">Heading</h4>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis pharetra varius quam sit amet vulputate.
                                Quisque mauris augue, molestie tincidunt condimentum vitae, gravida a libero. Aenean sit amet felis
                                dolor, in sagittis nisi. Sed ac orci quis tortor imperdiet venenatis. Duis elementum auctor accumsan.
                                Aliquam in felis sit amet augue.</p>
                            <ul class="list-inline list-unstyled">
                                <li><span><i class="glyphicon glyphicon-calendar"></i> dd, mm , yy </span></li>
                                <li>|</li>
                                <span>Posted by......Name</span>

                                <li>|</li>
                                <li>
                                    <!-- Use Font Awesome http://fortawesome.github.io/Font-Awesome/ -->
                                    <span><i class="fa fa-facebook-square"></i></span>
                                    <span><i class="fa fa-twitter-square"></i></span>
                                    <span><i class="fa fa-google-plus-square"></i></span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>


                <div class="well">
                    <div class="media">
                        <a class="pull-left" href="#">
                            <img class="media-object img-responsive" src="images/news-image2.jpg"/>
                        </a>
                        <div class="media-body">
                            <h4 class="media-heading">Heading</h4>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis pharetra varius quam sit amet vulputate.
                                Quisque mauris augue, molestie tincidunt condimentum vitae, gravida a libero. Aenean sit amet felis
                                dolor, in sagittis nisi. Sed ac orci quis tortor imperdiet venenatis. Duis elementum auctor accumsan.
                                Aliquam in felis sit amet augue.</p>
                            <ul class="list-inline list-unstyled">
                                <li><span><i class="glyphicon glyphicon-calendar"></i> dd, mm , yy </span></li>
                                <li>|</li>
                                <span>Posted by......Name</span>

                                <li>|</li>
                                <li>
                                    <!-- Use Font Awesome http://fortawesome.github.io/Font-Awesome/ -->
                                    <span><i class="fa fa-facebook-square"></i></span>
                                    <span><i class="fa fa-twitter-square"></i></span>
                                    <span><i class="fa fa-google-plus-square"></i></span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>


                <div class="well">
                    <div class="media">
                        <a class="pull-left" href="#">
                            <img class="media-object" src="images/news-image.jpg"  class="img-responsive"/>
                        </a>
                        <div class="media-body">
                            <h4 class="media-heading">Heading</h4>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis pharetra varius quam sit amet vulputate.
                                Quisque mauris augue, molestie tincidunt condimentum vitae, gravida a libero. Aenean sit amet felis
                                dolor, in sagittis nisi. Sed ac orci quis tortor imperdiet venenatis. Duis elementum auctor accumsan.
                                Aliquam in felis sit amet augue.</p>
                            <ul class="list-inline list-unstyled">
                                <li><span><i class="glyphicon glyphicon-calendar"></i> dd, mm , yy </span></li>
                                <li>|</li>
                                <span>Posted by......Name</span>

                                <li>|</li>
                                <li>
                                    <!-- Use Font Awesome http://fortawesome.github.io/Font-Awesome/ -->
                                    <span><i class="fa fa-facebook-square"></i></span>
                                    <span><i class="fa fa-twitter-square"></i></span>
                                    <span><i class="fa fa-google-plus-square"></i></span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>



            </div>






            <div class="pagination-section">
                <ul class="pagination">
                    <li class="page-item disabled">
                        <a class="page-link" href="#" tabindex="-1">Previous</a>
                    </li>
                    <li class="page-item active"><a class="page-link" href="#">1</a></li>
                    <li class="page-item">
                        <a class="page-link" href="#">2 <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                    <li class="page-item">
                        <a class="page-link" href="#">Next</a>
                    </li>
                </ul>
            </div>



        </div>



    </div>



</section>

<?php get_footer();?>
