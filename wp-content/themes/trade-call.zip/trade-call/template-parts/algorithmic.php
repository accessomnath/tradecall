<?php
/**
 * Created by PhpStorm.
 * User: Somnath
 * Date: 10-Jan-17
 * Time: 5:53 PM
 * Template name: Algorithmic Trading
 */
get_header()
?>

<section id="welcome-section-area">
    <div class="container">
        <div class="welcome-section-area-inner">
            <div class="welcome-section-area-inner-heading text-center">
                <h2>Algorithmic Trading</h2>
                <p><?php echo ot_get_option('algorithmic_trading_conent');?></p>
            </div>
            <div class="row">
                <div class="col-md-4 col-sm-6">
                    <figure class="snip-sec">
                        <img src="images/img-11.jpg" alt="img">
                        <figcaption>
                            <h3>Main heading</h3>
                            <h5>heading</h5>
                            <blockquote>
                                <p>Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit cursus a sit amet .</p>
                            </blockquote>
                        </figcaption>
                    </figure>
                    <a href="#" class="snip-btn">view more</a>
                </div>
                <div class="col-md-4 col-sm-6">
                    <figure class="snip-sec">
                        <img src="images/img-21.jpg" alt="img">
                        <figcaption>
                            <h3>Main heading</h3>
                            <h5>heading</h5>
                            <blockquote>
                                <p>Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit cursus a sit amet .</p>
                            </blockquote>
                        </figcaption>
                    </figure>
                    <a href="#" class="snip-btn">view more</a>
                </div>
                <div class="col-md-4 col-sm-6">
                    <figure class="snip-sec">
                        <img src="images/img-31.jpg" alt="img">
                        <figcaption>
                            <h3>Main heading</h3>
                            <h5>heading</h5>
                            <blockquote>
                                <p>Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit cursus a sit amet .</p>
                            </blockquote>
                        </figcaption>
                    </figure>
                    <a href="#" class="snip-btn">view more</a>
                </div>

                <div class="col-md-4 col-sm-6">
                    <figure class="snip-sec">
                        <img src="images/img-41.jpg" alt="img">
                        <figcaption>
                            <h3>Main heading</h3>
                            <h5>heading</h5>
                            <blockquote>
                                <p>Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit cursus a sit amet .</p>
                            </blockquote>
                        </figcaption>
                    </figure>
                    <a href="#" class="snip-btn">view more</a>
                </div>
                <div class="col-md-4 col-sm-6">
                    <figure class="snip-sec">
                        <img src="images/img-51.jpg" alt="img">
                        <figcaption>
                            <h3>Main heading</h3>
                            <h5>heading</h5>
                            <blockquote>
                                <p>Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit cursus a sit amet .</p>
                            </blockquote>
                        </figcaption>
                    </figure>
                    <a href="#" class="snip-btn">view more</a>
                </div>
                <div class="col-md-4 col-sm-6">
                    <figure class="snip-sec">
                        <img src="images/img-61.jpg" alt="img">
                        <figcaption>
                            <h3>Main heading</h3>
                            <h5>heading</h5>
                            <blockquote>
                                <p>Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit cursus a sit amet .</p>
                            </blockquote>
                        </figcaption>
                    </figure>
                    <a href="#" class="snip-btn">view more</a>
                </div>


            </div>


        </div>
    </div>

</section>

<?php get_footer();?>
