<?php
/**
 * Created by PhpStorm.
 * User: Somnath
 * Date: 10-Jan-17
 * Time: 5:53 PM
 * Template name: Traders
 */
get_header()
?>

<section id="welcome-section-area">
    <div class="container">
        <div class="welcome-section-area-inner">
            <div class="welcome-section-area-inner-heading text-center">
                <h2>Traders Education</h2>
                <p><?php echo ot_get_option('trader_content');?></p>
            </div>
            <div class="row">

                <div class="col-sm-4">
                    <div class="content-snip yellow">
                        <div class="image">
                            <img src="images/img-1.jpg" alt="img">
                            <div class="icons"><a href="#"><i class="fa fa-search"></i></a></div>
                        </div>
                        <figcaption>
                            <h3>Main <span>heading</span></h3>
                            <p>Lorem Ipsum is simply dummy text of the type setting industry. Industry's standard dummy text, when an unknown printer.</p>
                        </figcaption>
                        <a href="#"></a>
                    </div>

                </div>
                <div class="col-sm-4">
                    <div class="content-snip yellow">
                        <div class="image">
                            <img src="images/img-2.jpg" alt="img">
                            <div class="icons"><a href="#"><i class="fa fa-search"></i></a></div>
                        </div>
                        <figcaption>
                            <h3>Main <span>heading</span></h3>
                            <p>Lorem Ipsum is simply dummy text of the type setting industry. Industry's standard dummy text, when an unknown printer.</p>
                        </figcaption>
                        <a href="#"></a>
                    </div>

                </div>
                <div class="col-sm-4">
                    <div class="content-snip yellow">
                        <div class="image">
                            <img src="images/img-3.jpg" alt="img">
                            <div class="icons"><a href="#"><i class="fa fa-search"></i></a></div>
                        </div>
                        <figcaption>
                            <h3>Main <span>heading</span></h3>
                            <p>Lorem Ipsum is simply dummy text of the type setting industry. Industry's standard dummy text, when an unknown printer.</p>
                        </figcaption>
                        <a href="#"></a>
                    </div>

                </div>

                <div class="col-sm-4">
                    <div class="content-snip yellow">
                        <div class="image">
                            <img src="images/img-4.jpg" alt="img">
                            <div class="icons"><a href="#"><i class="fa fa-search"></i></a></div>
                        </div>
                        <figcaption>
                            <h3>Main <span>heading</span></h3>
                            <p>Lorem Ipsum is simply dummy text of the type setting industry. Industry's standard dummy text, when an unknown printer.</p>
                        </figcaption>
                        <a href="#"></a>
                    </div>

                </div>
                <div class="col-sm-4">
                    <div class="content-snip yellow">
                        <div class="image">
                            <img src="images/img-5.jpg" alt="img">
                            <div class="icons"><a href="#"><i class="fa fa-search"></i></a></div>
                        </div>
                        <figcaption>
                            <h3>Main <span>heading</span></h3>
                            <p>Lorem Ipsum is simply dummy text of the type setting industry. Industry's standard dummy text, when an unknown printer.</p>
                        </figcaption>
                        <a href="#"></a>
                    </div>

                </div>
                <div class="col-sm-4">
                    <div class="content-snip yellow">
                        <div class="image">
                            <img src="images/img-6.jpg" alt="img">
                            <div class="icons"><a href="#"><i class="fa fa-search"></i></a></div>
                        </div>
                        <figcaption>
                            <h3>Main <span>heading</span></h3>
                            <p>Lorem Ipsum is simply dummy text of the type setting industry. Industry's standard dummy text, when an unknown printer.</p>
                        </figcaption>
                        <a href="#"></a>
                    </div>

                </div>


            </div>


        </div>
    </div>

</section>

<?php get_footer();?>
